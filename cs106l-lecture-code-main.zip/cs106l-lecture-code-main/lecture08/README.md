# Lecture 7: Classes

You can take a look at the driver code in `main.cpp`. 

To compile this you can use the following command:

```sh
g++ -std=c++20 main.cpp StudentID.cpp IntVector.cpp -o main
```