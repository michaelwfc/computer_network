#include <iostream>

int main() {
    double pi;
    std::cout << "Enter pi: " << '\n';
    std::cin >> pi;
    std::cout << pi/2 << '\n';
    return 0;
}