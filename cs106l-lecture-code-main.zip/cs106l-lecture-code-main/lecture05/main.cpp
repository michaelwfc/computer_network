#include <iostream>

int main() {
  std::cout << "Read the README and run the examples from lecture!" << std::endl;
  return 0;
}
