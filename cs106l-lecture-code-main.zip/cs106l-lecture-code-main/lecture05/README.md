# Lecture 4: Streams

To compile this code, run:

```sh
g++ -std=c++23 <FILENAME>.cpp -o <FILENAME>
```

A lot of this code is expecting input from the terminal, so read throught he code and figure out what you're supposed to type in and where. If the terminal is "hanging" or not doing anything it's likely because it's expecting you to do something.