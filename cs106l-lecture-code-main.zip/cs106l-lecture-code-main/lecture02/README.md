# Lecture 2: Types and Structs

To run this code, make sure you have followed [the setup instructions in A0](https://github.com/cs106l/cs106l-assignments/tree/main/assign0). Then, you can compile and run using:

```sh
g++ main.cpp -o main
```

and 

```sh
./main
```