# CS106L Lecture Code

This repository contains code examples and lecture materials for Stanford CS106L, a course on Standard C++ programming. The code in this repository is meant to supplement the lectures and provide hands-on examples of the concepts discussed in class.

To compile and run code in this repository, make sure you have [completed A0 to setup your environment](https://github.com/cs106l/cs106l-assignments/tree/main/assign0).