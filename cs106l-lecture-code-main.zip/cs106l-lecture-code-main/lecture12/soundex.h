#pragma once

#include <string>

std::string soundex(const std::string& s);
std::string soundexRanges(const std::string& s);