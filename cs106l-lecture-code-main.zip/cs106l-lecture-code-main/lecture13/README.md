# Operator Overloading Lecture Code

## Compiling Instructions

```sh
g++ -std=c++20 main.cpp src/StanfordID.cpp -o main
```