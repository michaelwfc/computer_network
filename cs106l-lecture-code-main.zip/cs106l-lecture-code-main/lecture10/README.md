# Lecture 10: Template Classes and Const Correctness

Some example code that instantiates different `Vector<T>` has been included in `main.cpp`. The code written in lecture can be found in `Vector.h` and `Vector.cpp`.

To compile this you can use the following command:

```sh
g++ -std=c++20 main.cpp -o main
```