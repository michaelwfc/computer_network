# Lecture 11: Template Functions

To compile this you can use the following command:

```sh
g++ -std=c++20 main.cpp -o main
```
